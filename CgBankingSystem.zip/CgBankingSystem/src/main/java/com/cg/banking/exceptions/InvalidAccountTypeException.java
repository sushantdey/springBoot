package com.cg.banking.exceptions;
@SuppressWarnings("serial")
public class InvalidAccountTypeException extends Exception {

}

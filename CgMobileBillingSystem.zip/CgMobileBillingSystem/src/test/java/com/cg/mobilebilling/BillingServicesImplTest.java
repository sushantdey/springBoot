package com.cg.mobilebilling;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAOServices;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.services.BillingServicesImpl;

public class BillingServicesImplTest {

	public static BillingServices billingServices;
	private static PlanDAOServices mockPlanDAOService;
	private static CustomerDAOServices mockCustomerDAOService;
	private static PostpaidAccountDAOServices mockPostpaidAccountDAOService;
	private static BillingDAOServices mockBillingDAOServices;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		mockPlanDAOService = EasyMock.mock(PlanDAOServices.class);
		billingServices = new BillingServicesImpl(mockPlanDAOService);
		mockCustomerDAOService = EasyMock.mock(CustomerDAOServices.class);
		billingServices = new BillingServicesImpl(mockCustomerDAOService);
		mockPostpaidAccountDAOService = EasyMock.mock(PostpaidAccountDAOServices.class);
		billingServices = new BillingServicesImpl(mockPostpaidAccountDAOService);
		mockBillingDAOServices = EasyMock.mock(BillingDAOServices.class);
		billingServices = new BillingServicesImpl(mockBillingDAOServices);		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		
		billingServices=null;
		mockPlanDAOService=null;
		mockCustomerDAOService=null;
		mockPostpaidAccountDAOService=null;
		mockBillingDAOServices=null;
	
	}

	@Before
	public void setUp() throws Exception {
		Plan plan1=new Plan(150, 100, 100, 100, 100, 1024, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "bihar/jharkhand", "Diwali offer");
		Plan plan2=new Plan(250, 200, 200, 200, 200, 2048, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "pune", "Super offer");
		List<Plan> plans = new ArrayList<>();
		plans.add(plan1);
		plans.add(plan2);
		
		Customer customer = new Customer(1001, "Sushant", "Dey", "sushant@gmail.com", "15-04-1996", null, null);
		
		Address address1 = new Address(831002, "Jamshedpur", "Jharkhand");
		
		customer.setBillingAddress(address1);
		
		PostpaidAccount postpaidAccount1 = new PostpaidAccount(700430840, plan1, null);
		PostpaidAccount postpaidAccount2 = new PostpaidAccount(809243332, plan2, null);
		
		Bill bill1 = new Bill(1, 100, 100, 100, 100, 1000, "January", 172, 0, 0, 0, 0, 0, 15, 7, postpaidAccount1);
		Bill bill2 = new Bill(2, 100, 100, 100, 100, 1000, "February", 172, 0, 0, 0, 0, 0, 15, 7, postpaidAccount1);
		Bill bill3 = new Bill(3, 100, 100, 100, 100, 1000, "March", 172, 0, 0, 0, 0, 0, 15, 7, postpaidAccount2);
		Map<Integer, Bill> bills1=new LinkedHashMap<>();
		Map<Integer, Bill> bills2=new LinkedHashMap<>();
		bills1.put(1, bill1);
		bills1.put(2, bill2);
		bills2.put(1, bill3);
		
		postpaidAccount1.setBills(bills1);
		postpaidAccount2.setBills(bills2);
		
		EasyMock.expect(mockPlanDAOService.findAll()).andReturn(plans);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testGetPlanAllDetails() throws PlanDetailsNotFoundException, BillingServicesDownException{
		EasyMock.verify(mockPlanDAOService.findAll());
	}
	
	@Test
	public final void testAcceptCustomerDetails() throws BillingServicesDownException {
		Customer customer = new Customer(1001, "Sushant", "Dey", "sushant@gmail.com", "15-04-1996", null, null);
		Address address1 = new Address(831002, "Jamshedpur", "Jharkhand");
		customer.setBillingAddress(address1);
		billingServices.acceptCustomerDetails(customer);
	}

	@Test
	public final void testOpenPostpaidMobileAccount() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Plan plan1=new Plan(150, 100, 100, 100, 100, 1024, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "bihar/jharkhand", "Diwali offer");
		Plan plan2=new Plan(250, 200, 200, 200, 200, 2048, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "pune", "Super offer");
		
		Customer customer = new Customer(1001, "Sushant", "Dey", "sushant@gmail.com", "15-04-1996", null, null);
		
		Address address1 = new Address(831002, "Jamshedpur", "Jharkhand");
		
		customer.setBillingAddress(address1);
		billingServices.openPostpaidMobileAccount(customer.getCustomerID(),plan1.getPlanID());
	}

	@Test(expected=CustomerDetailsNotFoundException.class)
	public final void testOpenPostpaidMobileAccountFail() throws CustomerDetailsNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException{
		Plan plan1=new Plan(150, 100, 100, 100, 100, 1024, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "bihar/jharkhand", "Diwali offer");
		Plan plan2=new Plan(250, 200, 200, 200, 200, 2048, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "pune", "Super offer");
		
		/*Customer customer = *new Customer(1001, "Sushant", "Dey", "sushant@gmail.com", "15-04-1996", null, null);
		
		Address address1 = new Address(831002, "Jamshedpur", "Jharkhand");
		
		customer.setBillingAddress(address1);*/
		
		billingServices.openPostpaidMobileAccount(100,plan1.getPlanID());
	}
	@Test
	public final void testGenerateMonthlyMobileBill() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetCustomerDetails() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetAllCustomerDetails() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetCustomerAllPostpaidAccountsDetails() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetMobileBillDetails() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetCustomerPostPaidAccountAllBillDetails() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testChangePlan() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testCloseCustomerPostPaidAccount() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testDeleteCustomer() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetCustomerPostPaidAccountPlanDetails() {
		fail("Not yet implemented"); // TODO
	}

}

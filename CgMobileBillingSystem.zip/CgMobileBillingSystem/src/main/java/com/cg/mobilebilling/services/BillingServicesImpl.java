package com.cg.mobilebilling.services;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAOServices;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
@Component("billingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired
	private PlanDAOServices planDAOService;
	@Autowired
	private CustomerDAOServices customerDAOService;
	@Autowired
	private PostpaidAccountDAOServices postpaidAccountDAOService;
	@Autowired
	private BillingDAOServices billingDAOServices;
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		Plan plan=new Plan(150, 100, 100, 100, 100, 1024, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "pune", "offer");
		planDAOService.save(plan);
		List<Plan> listPlan=planDAOService.findAll();
		System.out.println(listPlan.toString());
		return listPlan;
	}

	@Override
	public int acceptCustomerDetails(Customer customer)
			throws BillingServicesDownException {
		customer=customerDAOService.save(customer);
		return customer.getCustomerID();
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAOService.findById(customerID).get();
		System.out.println(customer.toString());
		Plan plan=planDAOService.findById(planID).get();
		System.out.println(customer.toString());
		if(customer==null)
			throw new CustomerDetailsNotFoundException();
		if(plan==null)
			throw new PlanDetailsNotFoundException();
		PostpaidAccount postpaidAccount=new PostpaidAccount(customer,plan);
		postpaidAccount=postpaidAccountDAOService.save(postpaidAccount);
		System.out.println(postpaidAccount.getMobileNo());
		return postpaidAccount.getMobileNo();
	}

	@Override
	public int generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		PostpaidAccount postpaidAccount = postpaidAccountDAOService.findById(mobileNo).get();
		if(postpaidAccount==null)
			throw new PostpaidAccountNotFoundException();
		Plan plan=postpaidAccount.getPlan();
		if(plan==null)
			throw new PlanDetailsNotFoundException();
		
		if(noOfLocalSMS>plan.getFreeLocalSMS())
			noOfLocalSMS-=plan.getFreeLocalSMS();
		else
			noOfLocalSMS=0;
		
		if(noOfLocalCalls>plan.getFreeLocalCalls())
			noOfLocalCalls-=plan.getFreeLocalCalls();
		else
			noOfLocalCalls=0;
		
		if(noOfStdSMS>plan.getFreeStdSMS())
			noOfStdSMS-=plan.getFreeStdSMS();
		else
			noOfStdSMS=0;
		
		if(noOfStdCalls>plan.getFreeStdCalls())
			noOfStdCalls-=plan.getFreeStdCalls();
		else
			noOfStdCalls=0;
		
		if(internetDataUsageUnits>plan.getFreeInternetDataUsageUnits())
			internetDataUsageUnits-=plan.getFreeInternetDataUsageUnits();
		
		int localSMSAmount = (int) (noOfLocalSMS*plan.getLocalSMSRate());
		int stdSMSAmount = (int) (noOfStdSMS*plan.getStdSMSRate());
		int localCallAmount = (int) (noOfLocalCalls*plan.getLocalCallRate());
		int stdCallAmount = (int) (noOfStdCalls*plan.getStdCallRate());
		int internetDataUsageAmount = (int) (internetDataUsageUnits*plan.getInternetDataUsageRate());
		int monthlyRental=plan.getMonthlyRental();
		int billAmount=monthlyRental+localSMSAmount+stdSMSAmount+localCallAmount+stdCallAmount+internetDataUsageAmount;
		int servicesTax = (int)billAmount*10/100;
		int vat = (int)billAmount*5/100;
		int totalBillAmount = billAmount+servicesTax+vat;
		
		Bill bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount, internetDataUsageAmount, servicesTax, vat, postpaidAccount);
		bill=billingDAOServices.save(bill);
		return totalBillAmount;
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer = customerDAOService.findById(customerID).get();
		if(customer==null)
			throw new CustomerDetailsNotFoundException();
		//System.out.println(customer.toString());
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		return customerDAOService.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		PostpaidAccount postpaidAccount = postpaidAccountDAOService.findById(mobileNo).get();
		if(postpaidAccount==null)
			throw new PostpaidAccountNotFoundException();
		return postpaidAccount;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		if(customerDAOService.findById(customerID).isPresent()==false)
			throw new CustomerDetailsNotFoundException();
		return (List<PostpaidAccount>) customerDAOService.findById(customerID).get().getPostpaidAccounts().values();
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		if(customerDAOService.findById(customerID).isPresent()==false)
			throw new CustomerDetailsNotFoundException();
		if(postpaidAccountDAOService.findById(mobileNo).isPresent()==false)
			throw new PostpaidAccountNotFoundException();
		Bill bill = billingDAOServices.getMonthlyBill(customerID,mobileNo,billMonth);
		if(bill==null)
			throw new InvalidBillMonthException();
		return bill;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		if(customerDAOService.findById(customerID).isPresent()==false)
			throw new CustomerDetailsNotFoundException();
		if(postpaidAccountDAOService.findById(mobileNo).isPresent()==false)
			throw new PostpaidAccountNotFoundException();
		List<Bill> bills=billingDAOServices.getCustomerPostPaidAccountAllBills(customerID,mobileNo);
		if(bills==null)
			throw new BillDetailsNotFoundException();
		return bills;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		if(postpaidAccountDAOService.findById(mobileNo).isPresent()==false)
			throw new PostpaidAccountNotFoundException();
		if(planDAOService.findById(planID).isPresent()==false)
			throw new PlanDetailsNotFoundException();
		return postpaidAccountDAOService.changePlan(customerID,mobileNo,planID);
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		if(customerDAOService.findById(customerID).isPresent()==false)
			throw new CustomerDetailsNotFoundException();
		if(postpaidAccountDAOService.findById(mobileNo).isPresent()==false)
			throw new PostpaidAccountNotFoundException();
		postpaidAccountDAOService.deleteById(mobileNo);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		if(customerDAOService.findById(customerID).isPresent()==false)
			throw new CustomerDetailsNotFoundException();
		customerDAOService.deleteById(customerID);
		return true;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		if(customerDAOService.findById(customerID).isPresent()==false)
			throw new CustomerDetailsNotFoundException();
		PostpaidAccount postpaidAccount = postpaidAccountDAOService.findById(mobileNo).get();
		if(postpaidAccount==null)
			throw new PostpaidAccountNotFoundException();
		Plan plan=postpaidAccount.getPlan();
		if(plan==null)
			throw new PlanDetailsNotFoundException();
		return plan;
	}
}
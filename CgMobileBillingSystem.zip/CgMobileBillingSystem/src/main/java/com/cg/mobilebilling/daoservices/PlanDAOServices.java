package com.cg.mobilebilling.daoservices;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mobilebilling.beans.Plan;
@Qualifier("JpaRepository")
public interface PlanDAOServices extends JpaRepository<Plan, Integer>{
	
}
